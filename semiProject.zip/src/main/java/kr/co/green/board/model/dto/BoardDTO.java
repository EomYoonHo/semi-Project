package kr.co.green.board.model.dto;

public class BoardDTO {
	private int b_idx;
	private String b_title;
	private String b_content;
	private String m_nickname;
	private int m_no;
	private int b_views;
	private String b_inDate;
	private String b_updateDate;
	private String b_deleteDate;
	private String b_file_path;
	private String b_file_name;
	
	//
	
	
	
	public int getB_idx() {
		return b_idx;
	}
	public void setB_idx(int b_idx) {
		this.b_idx = b_idx;
	}
	public String getB_title() {
		return b_title;
	}
	public void setB_title(String b_title) {
		this.b_title = b_title;
	}
	public String getB_content() {
		return b_content;
	}
	public void setB_content(String b_content) {
		this.b_content = b_content;
	}
	public String getM_nickname() {
		return m_nickname;
	}
	public void setM_nickname(String m_nickname) {
		this.m_nickname = m_nickname;
	}
	public int getM_no() {
		return m_no;
	}
	public void setM_no(int m_no) {
		this.m_no = m_no;
	}
	public int getB_views() {
		return b_views;
	}
	public void setB_views(int b_views) {
		this.b_views = b_views;
	}
	public String getB_inDate() {
		return b_inDate;
	}
	public void setB_inDate(String b_inDate) {
		this.b_inDate = b_inDate;
	}
	public String getB_updateDate() {
		return b_updateDate;
	}
	public void setB_updateDate(String b_updateDate) {
		this.b_updateDate = b_updateDate;
	}
	public String getB_deleteDate() {
		return b_deleteDate;
	}
	public void setB_deleteDate(String b_deleteDate) {
		this.b_deleteDate = b_deleteDate;
	}
	
	
	
	
	
	
}
