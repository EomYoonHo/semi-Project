package kr.co.green.map.model.service;

import kr.co.green.map.model.dto.MapDTO;

public interface MapService {
	
	//first에 뿌려주기
	public void localSelect(MapDTO map);
}
