package kr.co.green.myList.model.dto;

public class MyListDTO {
	private int o_idx;
	private String o_name;
	private String o_paid_amount;
	private String o_period;
	private String o_buyer_name;
	private String o_paid_at;
	private int m_no;
	private String m_type;

	public String getM_type() {
		return m_type;
	}
	public void setM_type(String m_type) {
		this.m_type = m_type;
	}
	
	public int getM_no() {
		return m_no;
	}
	public void setM_no(int m_no) {
		this.m_no = m_no;
	}
	public int getO_idx() {
		return o_idx;
	}
	public void setO_idx(int o_idx) {
		this.o_idx = o_idx;
	}
	public String getO_name() {
		return o_name;
	}
	public void setO_name(String o_name) {
		this.o_name = o_name;
	}
	public String getO_paid_amount() {
		return o_paid_amount;
	}
	public void setO_paid_amount(String o_paid_amount) {
		this.o_paid_amount = o_paid_amount;
	}
	public String getO_period() {
		return o_period;
	}
	public void setO_period(String o_period) {
		this.o_period = o_period;
	}
	public String getO_buyer_name() {
		return o_buyer_name;
	}
	public void setO_buyer_name(String o_buyer_name) {
		this.o_buyer_name = o_buyer_name;
	}
	public String getO_paid_at() {
		return o_paid_at;
	}
	public void setO_paid_at(String o_paid_at) {
		this.o_paid_at = o_paid_at;
	}
	
	
	
	
	
	
}
