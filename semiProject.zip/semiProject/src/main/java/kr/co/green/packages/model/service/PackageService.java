package kr.co.green.packages.model.service;

import kr.co.green.packages.model.dto.PackageDTO;

public interface PackageService {
	public void packageSelect(PackageDTO pack);
}
