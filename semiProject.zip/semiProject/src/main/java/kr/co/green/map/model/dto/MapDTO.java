package kr.co.green.map.model.dto;

public class MapDTO {
	private int c_idx;
	private int l_idx;
	private String l_name;
	private String l_content1;
	private String l_content2;
	private String l_file_path;
	private String l_gps;
	
	
	public int getC_idx() {
		return c_idx;
	}
	public void setC_idx(int c_idx) {
		this.c_idx = c_idx;
	}
	public int getL_idx() {
		return l_idx;
	}
	public void setL_idx(int l_idx) {
		this.l_idx = l_idx;
	}
	public String getL_name() {
		return l_name;
	}
	public void setL_name(String l_name) {
		this.l_name = l_name;
	}
	public String getL_content1() {
		return l_content1;
	}
	public void setL_content1(String l_content1) {
		this.l_content1 = l_content1;
	}
	public String getL_content2() {
		return l_content2;
	}
	public void setL_content2(String l_content2) {
		this.l_content2 = l_content2;
	}
	public String getL_file_path() {
		return l_file_path;
	}
	public void setL_file_path(String l_file_path) {
		this.l_file_path = l_file_path;
	}
	public String getL_gps() {
		return l_gps;
	}
	public void setL_gps(String l_gps) {
		this.l_gps = l_gps;
	}
	
	
	
	
}
