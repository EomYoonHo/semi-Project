package kr.co.green.packages.model.dto;

public class PackageDTO {
	private int p_idx;
	private String p_name;
	private String p_content;
	private String p_file_path1;
	private String p_file_path2;
	private String p_file_path3;
	private int p_price;
	
	public int getP_idx() {
		return p_idx;
	}
	public void setP_idx(int p_idx) {
		this.p_idx = p_idx;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_content() {
		return p_content;
	}
	public void setP_content(String p_content) {
		this.p_content = p_content;
	}

	public String getP_file_path1() {
		return p_file_path1;
	}
	public void setP_file_path1(String p_file_path1) {
		this.p_file_path1 = p_file_path1;
	}
	public String getP_file_path2() {
		return p_file_path2;
	}
	public void setP_file_path2(String p_file_path2) {
		this.p_file_path2 = p_file_path2;
	}
	public String getP_file_path3() {
		return p_file_path3;
	}
	public void setP_file_path3(String p_file_path3) {
		this.p_file_path3 = p_file_path3;
	}
	public int getP_price() {
		return p_price;
	}
	public void setP_price(int p_price) {
		this.p_price = p_price;
	}
}







