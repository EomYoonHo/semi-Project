package kr.co.green.myAirList.model.dto;

public class MyAirListDTO {
	private int at_idx;
	private String at_airline;
	private int at_all_price;
	private String at_godate;
	private String at_backdate;
	private String at_buydate;
	private int m_no;
	private String m_type;
	public int getAt_idx() {
		return at_idx;
	}
	public void setAt_idx(int at_idx) {
		this.at_idx = at_idx;
	}
	public String getAt_airline() {
		return at_airline;
	}
	public void setAt_airline(String at_airline) {
		this.at_airline = at_airline;
	}
	public int getAt_all_price() {
		return at_all_price;
	}
	public void setAt_all_price(int at_all_price) {
		this.at_all_price = at_all_price;
	}
	public String getAt_godate() {
		return at_godate;
	}
	public void setAt_godate(String at_godate) {
		this.at_godate = at_godate;
	}
	public String getAt_backdate() {
		return at_backdate;
	}
	public void setAt_backdate(String at_backdate) {
		this.at_backdate = at_backdate;
	}
	public String getAt_buydate() {
		return at_buydate;
	}
	public void setAt_buydate(String at_buydate) {
		this.at_buydate = at_buydate;
	}
	public int getM_no() {
		return m_no;
	}
	public void setM_no(int m_no) {
		this.m_no = m_no;
	}
	public String getM_type() {
		return m_type;
	}
	public void setM_type(String m_type) {
		this.m_type = m_type;
	}
	
	

	
	
}
